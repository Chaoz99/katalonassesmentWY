
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */



def static "projectweb.commonuse.loginadmin"() {
    (new projectweb.commonuse()).loginadmin()
}


def static "projectweb.commonuse.randomname"(
    	int length	) {
    (new projectweb.commonuse()).randomname(
        	length)
}
